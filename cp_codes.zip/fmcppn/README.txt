MATLAB codes for detecting multiple core-periphery pairs in networks.
The implemented algorithms are the Kojaku-Masuda algorithm [1], two-step algorithm [1] and the discrete variant of the Borgatti-Everett algorithm.

Please cite
	Kojaku, S. and Masuda, N. Finding core-periphery pairs in networks. Preprint arXiv:???? (2017).
———————————————————————————————————————————————————————————————————————————

FILES:

  Directory lib/ contains .m files.

  example_adj_mat.txt is an example adjacency matrix of a network as input.

  example_edge_list.txt is an example edge list of a network as input.


INPUT:

  An adjacency matrix (e.g., example_adj_mat.txt) or an edge list (e.g., example_edge_list.txt)


USAGE:

  % Load the library. Specify the absolute or relative path to the "lib" directory.
  addpath ./lib

  % Read data files
  A = load('example_adj_mat.txt'); % Case of an adjacency matrix
  L = load('example_edge_list.txt'); % Case of an edge list

  clear param;

  % create class object
  cpa = cpalgorithm();

  % Set the parameter values. See below for optional parameters.
  param = cpa.init('km');
  % 'km': Kojaku-Masuda algorithm
  % 'two-step': two-step algorithm
  % 'be': discrete variant of the Borgatti-Everett algorithm

  % Run the detection algorithm. Two input formats are allowed.
  % (1) Adjacency matrix
  [C,P,Q,Qs,score,param,cpu_time] = cpa.detect(A,param);

  % (2) Edge list
  [C,P,Q,Qs,score,param,cpu_time] = cpa.detect(L,param);


OPTIONS:

  % Display message.
 	% Default: false
  param.disp = true;

  % Set the significance level for the statistical test.
 	% Usually 0.01 or 0.05; we used 0.01 in Ref. [1].
 	% If this option is not set, the statistical test will be skipped.
  param.pval = 0.01;

  % Number of random graph instances used in the statistical test
 	% Default: 3000
  param.numRandGraph = 3000;

  % Change the null model to the configuration model
 	% (see the Discussion section of Ref. [1]).
  param.nullmodel = 'config';

  % Number of times we run the algorithm
 	% The final output is the core-periphery pairs that yield the largest Q.
	% Default: 20
  param.numRun = 20;

  % Auxiliary command: Display all parameter/option values.
  param


OUTPUT:

  C: N x K 0-1 matrix (in the sparse matrix format) such that C(i,k) =1 if the i-th node belongs to the k-th core-periphery pair as core node.
  Run full(C) to view it as a full matrix.

  P: N x K 0-1 matrix (in the sparse matrix format) such that P(i,k) =1 if the i-th node belongs to the k-th core-periphery pair as peripheral node.
  Run full(P) to view it as a full matrix.

  Q: Quality of the detected core-periphery pairs.

  Qs: Row vector of size K such that its k-th entry is the contribution of the k-th core-periphery pair to Q.
  Note that sum(Qs) is equal to Q.

  score: Column vector of size N such that its i-th entry is the contribution of the i-th node to Q.
  Note that sum(score) is equal to Q.

  param: parameter values. When they are not specified in the input, the default values are used and stored in this variable.

  cpu_time: CPU time consumed (secs)


Requirement: MATLAB 2012 or later.
———————————————————————————————————————————————————————————————————————————
References
[1] Kojaku, S. and Masuda, N. Finding core-periphery pairs in networks. Preprint arXiv:???? (2017). http://??????
[2] Borgatti, S. P. and Everett, M. G. Model of core/periphery structures. Soc. Netw. 21, 375–395 (2000).
———————————————————————————————————————————————————————————————————————————
Last updated: 22 February 2017
