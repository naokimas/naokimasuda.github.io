% Two-step algorithm
%
% @version 0.1.0
% @date 2017/02/19
%
% @author Sadamori Kojaku 
classdef two_step_cp 

	methods ( Access = public )

		function [C, P, Q, Qs, score, param, cpu_time] = detect( self, G, varargin )
			% --------------------------------
			% Initialise
			% --------------------------------
			param = [];
			if nargin == 3
				param = varargin{1};
			end
			param = self.initParam( param );
			C= []; P = []; Q = -Inf; score = [];
			cpu_time = cputime;	
			
			% --------------------------------
			% Detect a single core-periphery pair and communities  
			% --------------------------------
			cpd = be_cp();
			[C, P] = cpd.detect( G, param );	
			U = self.louvain_algorithm( G, param );
				
			C = sparse( 1:size( C, 1 ), 1:size( C, 1 ), C ) * U;
			P = U - C;
			[Q, Qs, score] = self.eval( G, C, P );
			cpu_time = cputime - cpu_time;
		end
		
		function [q, qs, score] = eval( self, G, C, P, varargin )
			qs = ones( 1, size( C, 2 ) ) * NaN; q = NaN;
			score = ones( G.numNode(), 1 ) * NaN;
		end
		
		function param = initParam( self, param )
			if ~isfield( param, 'disp' ); param.disp = false; end
			if ~isfield( param, 'numRun' ); param.numRun = 20; end
		end
	end
	
	methods ( Access = private )
					
		function [C, Q, Qs] = louvain_algorithm( self, G, param )
			C = []; P = []; Qs = []; score = []; Q = - Inf;
			for it = 1:param.numRun	
				[Ct, Qt, Qst] = self.louvain_private( G, param );
				if Qt > Q	
					C = Ct; Q = Qt; Qs = Qst; 
				end
			end
		end
			
		function [C, Q, Qs] = louvain_private( self, G, param )
			% -------------------------------- 
			% Initialise
			% -------------------------------- 
			deg = G.degree();
			N = G.numNode();
			M = G.numEdge();
			C = sparse( 1:N, 1:N, 1 );
			A = G.adjacency_matrix();
			At = A;
			degt = deg;
			dQ = 0; 
			q = 0;
			first = true;
			Qbest = - Inf;
			
			% -------------------------------- 
			% Optimise node labels 
			% -------------------------------- 
			while size( At, 1 ) ~= 1
				[Ct, dq] = first_step( At, degt, M, param );	
				C = C * Ct;
				q = myeval( C, A, deg, M );	
				if ( abs( Qbest - q ) < eps & rand() > 0.5 ) | Qbest < q 
					Qbest = q; Cbest = C;
				end
				[At, degt] = second_step( At, degt, Ct );
				if size( Ct, 1 ) == size( Ct, 2 )
					break;
				end
			end
			C = Cbest;
			[Q, Qs] = myeval( C, A, deg, M );
			
			function [U, dQ] = first_step( A, d, M, param, varargin )
				dQ = 0;
				n = size( A, 1 );
				
				if nargin == 5
					U = varargin{ 1 };
				else
					U = sparse( 1:n, 1:n, 1 );
				end
				dQ = 0;
				vAv = diag( A );	
				[~, ord] = sort( rand( 1, n ) );
				update = true;
				while( update )
					update = false;
					for nid = ord
						isin = any( U( nid, : ), 1 );
						vAc = A( nid, : ) * U;vAc( isin )= vAc( isin ) - vAv( nid );
						dU = d' * U; dU( isin ) = dU( isin ) - d( nid );
						qp = vAc / ( 2 * M ) - d( nid ) * dU / ( 4 * M^2 );
						[dq, next_cid] = max( qp );
						if dq <= eps | isin( next_cid )== 1; continue; end
						update = true;
						dQ = dQ + 2 * dq;	
						U( nid, isin ) = 0; 
						U( nid, next_cid ) = 1; 
						if any( U( :, isin ) ) == false
							U( :, isin ) = [];
						end 
					end
				end
			end

			function [An, dn] = second_step( Al, dl, Cl )
				An = Cl' * Al * Cl;
				dn = ( dl' * Cl )';
			end
			
			function [q, qs] = myeval( C, A, d, M )
				qs = zeros( size( C, 2 ), 1 );
				for k = 1:size( C, 2 )
					qs( k ) = C( :, k )' * A * C( :, k ) - ( sum( d( C( :, k )>0 ) )^2 ) / ( 2 * M );
				end
				qs = qs / ( 2 * M );
				q = sum( qs );
			end
		end	
	end
end
