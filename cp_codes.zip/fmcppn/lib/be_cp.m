% Discrete variant of the Borgatti-Everett algorithm 
%
% @version 0.1.0
% @date 2017/02/19
%
% @author Sadamori Kojaku 
classdef be_cp 

	methods ( Access = public )

		function [C, P, Q, Qs, score, param, cpu_time] = detect( self, G, varargin )
			% --------------------------------
			% Initialise
			% --------------------------------
			param = [];
			if nargin == 3
				param = varargin{1};
			end
			param = self.initParam( param );
			C= []; P = []; Q = -Inf; score = [];
			ts = cputime;
			
			% --------------------------------
			% Optimise node labels using the Kernighan-Lin algorithm 
			% --------------------------------
			for it = 1:param.numRun
				[Ct, Pt, Qt, Qst, scoret] = self.Kernighan_Lin_algorithm( G, param );
				if Qt > Q
					C = Ct; P = Pt; Q = Qt; score = scoret; Qs = Qst;
				end
			end
			
			cpu_time = cputime - ts;
		end
		
		function [Q, Qs, score] = eval( self, G, x, varargin )
			N = G.numNode(); 
			deg = G.degree();
			A = G.adjacency_matrix(); 
			Nperi = N-sum( x );
			p = sum( A( : ) ) / ( N * ( N - 1 ) );
			pb = ( N * ( N - 1 ) - Nperi * ( Nperi - 1 ) ) / ( N * ( N - 1 ) );
			vara = p * ( 1 - p ) * N * ( N - 1 ) / 2;	
			varb = pb * ( 1 - pb ) * N * ( N - 1 ) / 2;
			Dcore = A * x;
			score = ( - deg * pb / 2 + x .* deg / 2 + ( 1 - x ) .* Dcore / 2 ) / ( sqrt( vara ) * sqrt( varb ) );
			Q = sum(score); Qs = Q;
		end
		
		function param = initParam( self, param )
			if ~isfield( param, 'numRun' ); param.numRun = 20; end
			if ~isfield( param, 'name' ); param.name = 'be'; end
		end
	end
	
	methods ( Access = private )

		function [C, P, Q, Qs, score] = Kernighan_Lin_algorithm( self, G, param )
			% --------------------------------
			% Initialise
			% --------------------------------
			N = G.numNode(); 
			deg = G.degree(); 
			L = N * ( N - 1 ) / 2; 
			M = G.numEdge(); 
			A = G.adjacency_matrix(); 
			while true; C = round( rand( N, 1 ) ); if ~all( C ) & ~all( ~C ); break; end;end 
			Ncore = sum( C ); 
			Mb = N * ( N - 1 ) / 2 - ( N - Ncore )*( N - Ncore - 1 )/2; 
			Dcore = A * C; 
			[Q, ~, ~] = self.eval( G, C ); 
			Mcp = C' * deg - C' * Dcore / 2; 
			x = C;
			
			% --------------------------------
			% Maximise the Borgatti-Everett (BE) quality function 
			% --------------------------------
			for j = 1:N		
				fixed = false( N, 1 ); 
				Qold = ( Mcp - Mb * M / L ) / sqrt( Mb * ( L - Mb ) );
				dQ = 0; dQmax = - Inf;
				for i = 1:N
					dMb = ( Ncore - N ) .* x + ( N - Ncore - 1 ) .* ( 1 - x ); 
					dMcp = ( Dcore - deg ); dMcp( x==0 ) = -dMcp( x==0 );
					dq = ( Mcp + dMcp - ( Mb + dMb ) * M / L ) ./ sqrt( ( Mb + dMb ) .* ( L - ( Mb + dMb ) ) );
					dq( fixed ) = - Inf; dq( isinf( dq ) ) = - Inf;
					[dqmax, nid] = max( dq ); 
					Ncore = Ncore - ( 2 * x( nid ) - 1 );
					Mb = Mb + dMb( nid );				
					Mcp = Mcp + dMcp( nid );
					Dcore = Dcore + A( :, nid ) * ( - 2 * x( nid ) + 1 );	
					x( nid ) = 1 - x( nid );
					dQ = dQ + dqmax - Qold;
					Qold = dqmax;
					if dQmax < dQ
						xbest = x;
						dQmax = dQ;
						Ncorebest = Ncore; Mbbest = Mb; Mcpbest = Mcp; Dcorebest = Dcore;
					end
					fixed( nid ) = true; 
				end
				if dQmax < eps;
					break;
				end
				Ncore = Ncorebest; Mb = Mbbest; Mcp = Mcpbest; Dcore = Dcorebest;
				x = xbest; C = xbest;
			end
		
			% --------------------------------
			% Calculate the quality of the detected core-periphery pair 
			% --------------------------------
			P = 1 - C; 
			[Q, Qs, score] = self.eval( G, C, P );
		end
	end
end
