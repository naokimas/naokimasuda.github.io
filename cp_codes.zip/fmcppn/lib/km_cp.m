% Kojaku-Masuda algorithm
%
% @version 0.1.0
% @date 2017/02/19
%
% @author Sadamori Kojaku 
classdef km_cp
	
	methods ( Access = public )
		
		function [C, P, Q, Qs, score, param, cpu_time] = detect( self, G, varargin )
			% --------------------------------
			% Initialise
			% --------------------------------
			param = [];
			if nargin == 3
				param = varargin{1};
			end
			param = self.initParam( param );
			C = []; P = []; Qs = []; score = []; Q = - Inf;
			cpu_time = cputime;
	
			% --------------------------------
			% Optimise node labels using a label switching algorithm 
			% --------------------------------
			for it = 1:param.numRun 
				ts = cputime;
				if strcmp( param.null_model, 'erdos-renyi' ) % If the null model is the Erdős–Rényi random graph
					[Ct, Pt, Qt, Qst] = self.label_switching_algorithm_erdos_renyi( G, param ); 
				elseif strcmp( param.null_model, 'config' ) % If the null model is the configuratin model 
					[Ct, Pt, Qt, Qst] = self.label_switching_algorithm_config( G, param );
				end
				if Qt > Q
					C = Ct; P = Pt; Q = Qt; Qs = Qst; 
				end
				if param.disp; disp( sprintf( '%d/%d finished ( max Q = %f, %f seconds )', it, param.numRun, full( Q ), cputime - ts ) ); end
			end
			cpu_time = cputime - cpu_time;
		end
		
		function [Q, Qs, score] = eval( self, G, C, P, varargin )
			% --------------------------------
			% Calculate Q using the configuration model as the null model
			% --------------------------------
			if nargin == 5 
				param = varargin{1};
				if strcmp( param.null_model, 'config' )
					R = G.modularity_matrix(); 
					x = any( C, 2 );
					score = ( R * ( C + diag( x ) * P ) ) .* ( C + P );
					Qs = sum( score, 1 ); score = sum( score, 2 );	
					Q = sum( Qs );
					return;
				end
			end
		
			% --------------------------------
			% Calculate Q using the Erdős–Rényi random graph null model
			% --------------------------------
			Nc = sum( C ); Np = sum( P ); N = G.numNode();
			p = G.density();
			A = G.adjacency_matrix();
			Dcore = A * C; Dperi = A * P;
			x = any( C, 2 );
			U = C + P;
			score = Dcore + diag( x ) * Dperi;
			score = score .* U - p * ( U * diag( Nc ) - diag( x ) * U * diag( Np - 1 ) );
			Qs = sum( score, 1 ); score = sum( score, 2 ); Q = sum( Qs );
		end
	
		function param = initParam( self, param )
			if isempty( param )	
				param.name = 'km';
			end	
			if ~isfield( param, 'numRun' ); param.numRun = 20; end
			if ~isfield( param, 'null_model' ); param.null_model = 'erdos-renyi'; end
			if ~isfield( param, 'disp' ); param.disp = false; end
		end
	end
	
	methods ( Access = private )
		
		function [C, P, Q, Qs] = label_switching_algorithm_erdos_renyi( self, G, param )
			% --------------------------------
			% Initialise
			% --------------------------------
			N = G.numNode();
			A = G.adjacency_matrix(); 
			activeNodes = find( any( A, 1 ) ); 
			C = sparse( 1:N, 1:N, 1 ); P = sparse( N, N, 0 ); 
			Ncore = ones( 1, N ); 
			Nperi = zeros( 1, N );
			x = true( N, 1 );
			Dcore = A;
			Dperi = sparse( N, N, 0 );
			p = G.density();
				
			% --------------------------------
			% Optimise node labels 
			% --------------------------------
			isUpdated = true;	
			while isUpdated
				isUpdated = false;
				if param.disp; ts = cputime; end; ts = cputime;
				ord = self.order_randomly( activeNodes ); 
				for nid = ord
					pairId = find( C( nid, : ) + P( nid, : ), 1, 'first' ); 
					neiPairId = find( Dcore( nid, : ) + Dperi( nid, : ) ); 
				
					% Calculate the increment in Q obtained by changing the label of node nid
					dQperi = Dcore( nid, neiPairId ) - p * ( Ncore( neiPairId ) - double( pairId == neiPairId ) ); 
					dQcore = dQperi + Dperi( nid, neiPairId ) - p * Nperi( neiPairId );
					q0 = Dcore( nid, pairId ) + Dperi( nid, pairId ) * x( nid ) - p * ( Ncore( pairId ) + Nperi( pairId ) * x( nid ) - x( nid ) );
					dQperi = dQperi - q0; dQcore = dQcore - q0;
					if x( nid ); dQcore( neiPairId == pairId ) = 0; else; dQperi( neiPairId == pairId ) = 0; end
				
					[val, idx] = max( [dQperi, dQcore] );
					if val <= 0; continue; end 
					nextx = idx > length( dQperi ); 
					nextPairId = neiPairId( idx - length( dQperi ) * double( nextx ) ); 
					if nextx 
						C( nid, nextPairId ) = 1;
						Dcore( :, nextPairId ) = Dcore( :, nextPairId ) + A( :, nid ); 
						Ncore( nextPairId ) = Ncore( nextPairId ) + 1;
					else 
						P( nid, nextPairId ) = 1; 
						Dperi( :, nextPairId ) = Dperi( :, nextPairId ) + A( :, nid ); 
						Nperi( nextPairId ) = Nperi( nextPairId ) + 1;
					end
					if x( nid ) 
						C( nid, pairId ) = 0;
						Ncore( pairId ) = Ncore( pairId ) - 1;
						Dcore( :, pairId ) = Dcore( :, pairId ) - A( :, nid );
					else 
						P( nid, pairId ) = 0;
						Nperi( pairId ) = Nperi( pairId ) - 1;
						Dperi( :, pairId ) = Dperi( :, pairId ) - A( :, nid ); 
					end
					isUpdated = true;
					x( nid ) = nextx;
				end
					
				% Remove unused labels	
				unused = Ncore == 0 & Nperi == 0;
				if any( unused ) 
					C( :, unused ) = []; P( :, unused ) = [];
					Ncore( unused ) = []; Nperi( unused ) = [];
					Dcore( :, unused ) = []; Dperi( :, unused ) = [];
				end

				cpu_time = cputime - ts;
			end
			
			% --------------------------------
			% Calculate Q and Qs of the detected core-periphery pairs
			% --------------------------------
			Qs = diag( ( C + P )' * A * ( C + P ) - P' * A * P )' - p * ( Ncore + Nperi ) .^2 + p * Nperi .^2; 
			Q = sum( Qs );
		end	
		
		function [C, P, Q, Qs, score] = label_switching_algorithm_config( self, G, param )
			% --------------------------------
			% Initialise
			% --------------------------------
			N = G.numNode(); 
			A = G.adjacency_matrix(); 
			activeNodes = find( any( A, 1 ) ); 
			C = sparse( 1:N, 1:N, 1 );P = sparse( N, N, 0 ); 
			Ncore = ones( 1, N ); 
			Nperi = zeros( 1, N ); 
			x = true( N, 1 ); 
			Dcore = A; 
			Dperi = sparse( N, N, 0 ); 
			deg = G.degree(); 
			M = sum( deg ) / 2; 
			R = G.modularity_matrix(); 
			
			% --------------------------------
			% Optimise node labels 
			% --------------------------------
			isUpdated = true;
			while isUpdated 
				isUpdated = false;
				if param.disp; ts = cputime; end; ts = cputime;
				ord = self.order_randomly( activeNodes ); 
				for nid =ord
					pairId = find( C( nid, : ) + P( nid, : ), 1, 'first' ); 
					neiPairId = find( Dcore( nid, : ) + Dperi( nid, : ) ); 
					
					% Calculate the increment in Q obtained by changing the label of node nid
					dQperi = R( nid, : ) * C( :, neiPairId ); 
					dQcore = dQperi + R( nid, : ) * P( :, neiPairId ); 
					q0 = R( nid, : ) * ( C( :, pairId ) + double( x( nid ) ) * (P( :, pairId )) ) - double( x( nid ) ) * R(nid,nid) ;
					dQperi = dQperi - q0; dQcore = dQcore - q0;
					if x( nid ); dQcore( neiPairId == pairId ) = 0; else; dQperi( neiPairId == pairId ) = 0 ;end;
					
					[val, idx] = max( [dQperi, dQcore] );
					if val < eps; continue; end 
					nextx = idx > length( dQperi ); 
					nextPairId = neiPairId( idx - length( dQperi ) * double( nextx ) ); 
					if nextx 
						C( nid, nextPairId ) = 1;
						Dcore( :, nextPairId ) = Dcore( :, nextPairId ) + A( :, nid ); 
						Ncore( nextPairId ) = Ncore( nextPairId ) + 1;
					else 
						P( nid, nextPairId ) = 1; 
						Dperi( :, nextPairId ) = Dperi( :, nextPairId ) + A( :, nid ); 
						Nperi( nextPairId ) = Nperi( nextPairId ) + 1;
					end
					if x( nid ) 
						C( nid, pairId ) = 0;
						Ncore( pairId ) = Ncore( pairId ) - 1;
						Dcore( :, pairId ) = Dcore( :, pairId ) - A( :, nid );
					else 
						P( nid, pairId ) = 0;
						Nperi( pairId ) = Nperi( pairId ) - 1;
						Dperi( :, pairId ) = Dperi( :, pairId ) - A( :, nid ); 
					end
					isUpdated = true;
					x( nid ) = nextx;
				end	
				
				% Remove unused labels	
				unused = Ncore == 0 & Nperi == 0;
				if any( unused ) 
					C( :, unused ) = []; P( :, unused ) = [];
					Ncore( unused ) = []; Nperi( unused ) = [];
					Dcore( :, unused ) = []; Dperi( :, unused ) = [];
				end
			end
			
			% --------------------------------
			% Calculate the quality of the detected core-periphery pairs
			% --------------------------------
			Qs = diag( ( C + P )' * R * ( C + P ) - P' * R * P )'; 
			Q = sum( Qs );
		end
		
		function nids = order_randomly( self, ids )
			[val, ord] = sort( rand( length( ids ), 1 ) );	
			nids = ids( ord );
		end		
	end
end
