% Container class for be_cp, two_step_cp and km_cp classes
% 
% @version 0.1.0
% @date 2017/02/19
%
% @author Sadamori Kojaku 
classdef cpalgorithm

	properties
		algorithms;
	end

	methods ( Access = public )

		function obj = cpalgorithm()	
			obj.algorithms = { % List of algorithms
				% Borgatti-Everett algorithm
				'be', be_cp();
				
 				% Two-step algorithm
				'two-step', two_step_cp(); 
				
				% Kojaku-Masuda algorithm
				'km', km_cp();
			};	
		end
		
		function [C, P, Q, Qs, score, param, cpu_time] = detect( self, A, param )
			% --------------------------------
			% Initialise
			% --------------------------------
			G = graph_wrapper( A );
			
			% --------------------------------
			% Detect core-periphery pairs 
			% --------------------------------
			cpd = self.select_algorithm( param.name );	
			[C, P, Q, Qs, score, param, cpu_time] = cpd.detect( G, param );
			
			% --------------------------------
			% Estimate the significance of the detected core-periphery pairs 
			% --------------------------------
			if isfield( param, 'pval' )
				slice = self.statistical_test( C, P, G, param );
				if ~any(slice);
					C = sparse( G.numNode(), 1, 0 ); P=C;
				else
					C = C( :, slice ); P = P( :, slice );
				end
				[Q, Qs, score] = cpd.eval( G, C, P, param );
			end
		end
	
		function [q, qs, score] = eval( self, A, C, P, param )
			cpd = self.select_algorithm( param.name );
			[q, qs, score] = cpd.eval( graph_wrapper(A), C, P, param );
		end
		
		function significant = statistical_test( self, C, P, G, param )
			% --------------------------------
			% Initialise
			% --------------------------------
			if param.disp
				disp( 'starting statistical test...' );
			end
			if isfield( param, 'numRandGraph' )
				numRandGraph = param.numRandGraph;
			else
				numRandGraph = 3000;	
			end
			significant = true( 1, size( C, 2 ) );
			clear cpa_a;		
			cpa_a.name = 'kl';	
			be = be_cp();
			corrected_pval = 1 - ( 1 - param.pval ) ^( 1 / size( C, 2 ) ); 
			 
			% --------------------------------
			% Estimate the significance of each core-periphery pair 
			% --------------------------------
			A = G.adjacency_matrix();
			for k = 1:size( C, 2 ) 
				if sum( C( :, k ) + P( :, k ), 1 )<=2; significant( k )=false; continue; end
				nids = any( C( :, k ) + P( :, k ), 2 ); 
				Ns = nnz( nids ); 
				As = A( nids, nids ); 
				q = be.eval( graph_wrapper(As), C( nids, k ) ); 
				if param.disp
					disp( sprintf( 'testing core-periphery pair %d', k ) );
				end
				L = nchoosek( 1:Ns, 2 ); eids = sub2ind( [Ns, Ns], L( :, 1 ), L( :, 2 ) );
					
				a = As( eids );
				counter = 0;
				for t = 1:numRandGraph 
					At = sparse( L( :, 1 ), L( :, 2 ), self.shuffle_order( a ), Ns, Ns ); At = At + At'; 
					[ ~, ~, qt ] = be.detect( graph_wrapper(At), cpa_a ); 
					if q <= qt
						counter = counter + 1;
						if ( counter / numRandGraph ) > corrected_pval
							significant( k ) = false;
							break	
						end
					end
				end
			end
		end
		
		function param = init( self, name )
			cpa = self.select_algorithm( name );
			clear alg; 
			param.name =name; 
			param = cpa.initParam( param );	
		end
	end
	
	methods ( Access = private )

		function cpd = select_algorithm( self, name )
			cpd = [];	
			for i = 1:size( self.algorithms, 1 )
				if strcmp( self.algorithms{i, 1}, name )
					cpd = self.algorithms{i, 2};	
					break
				end
			end
		end	
	
		function nids = shuffle_order( self, ids )
			[val, ord] = sort( rand( length( ids ), 1 ) );	
			nids = ids( ord );
		end		
	end
end	
