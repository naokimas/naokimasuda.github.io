% Wrapper class for different data formats 
%
% @version 0.1.0
% @date 2017/02/19
%
% @author Sadamori Kojaku 
classdef graph_wrapper

	properties
		A; % Adjacency matrix
		deg; % deg( i ) is the degree of node i 
		N; % Number of nodes
		M; % Number of edges
	end
	
	methods ( Access = public )

		% A: an N x N adjacency matrix or an M x 2 matrix of an edge list 
		function obj = graph_wrapper( A )
			if size( A, 1 ) == size( A, 2 ) % A is an adjacency matrix
				if ~isequal( A, A' ) 
					obj.A = sign( A + A' );
				else
					obj.A = sign( A );
				end
				obj.N = size( A, 1 );	
			elseif size( A, 2 ) <= 3 % A is a matrix of an edge list 
				obj.N = max( [A( :, 1 ); A( :, 2 )] );
				if size( A, 2 ) > 2
					B = sparse( A( :, 1 ), A( :, 2 ), A( :, 3 ), obj.N, obj.N );
				else
					B = sparse( A( :, 1 ), A( :, 2 ), 1, obj.N, obj.N );
				end
				if ~isequal( B, B' ) 
					obj.A = sign( B + B' );
				else
					obj.A = sign( B );
				end
			end
			ind = sub2ind( size( obj.A ), 1:obj.N, 1:obj.N );
			obj.A( ind ) = 0;	
			obj.deg = sum( obj.A, 2 );
			obj.M = sum( obj.deg ) / 2;	
		end
		
		function A = adjacency_matrix( self )
			A = self.A;
		end

		function M = modularity_matrix( self )
			M = ( self.A - self.deg * self.deg' / ( 2 * self.M ) ) / ( 2 * self.M );
		end
		
		function deg = degree( self )
			deg = self.deg;
		end

		function d = numNode( self )
			d = self.N;
		end

		function d = numEdge( self )
			d = self.M;
		end

		function d = density( self )
			n = sum( self.deg > 0 );
			d = ( 2 * self.M ) / ( n * ( n-1 ) );
		end
	end
end
